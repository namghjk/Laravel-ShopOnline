<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;
use Spatie\Permission\Models\Role;

Route::post('auth/login', [AuthController::class, 'login'])->name('login');

Route::group([
    'middleware' => 'api',
    'prefix' => 'auth'
], function ($router) {
    Route::post('create', [AuthController::class, 'create']);
    Route::post('update', [AuthController::class, 'update']);
    Route::post('login', [AuthController::class, 'login']);
    Route::post('logout', [AuthController::class, 'logout']);
    Route::post('updateAvatar', [AuthController::class, 'updateAvatar']);
    Route::post('me', [AuthController::class, 'me']);
});

Route::group([
    'middleware' => 'api',
    'prefix' => 'products'
], function ($router) {
    Route::get('view', [ProductController::class, 'view']);
    Route::post('create', [ProductController::class, 'create']);
    Route::post('update', [ProductController::class, 'update']);
    Route::get('delete', [ProductController::class, 'delete']);
});

Route::group([
    'middleware' => 'api',
    'prefix' => 'categories'
], function ($router) {
    Route::get('view', [CategoryController::class, 'view']);
    Route::get('detail', [CategoryController::class, 'detail']);
    Route::get('getMenu', [CategoryController::class, 'getMenu']);
    Route::post('create', [CategoryController::class, 'create']);
    Route::post('update', [CategoryController::class, 'update']);
    Route::get('delete', [CategoryController::class, 'delete']);
});

Route::group([
    'middleware' => 'api',
    'prefix' => 'posts'
], function ($router) {
    Route::get('view', [PostController::class, 'view']);
    Route::get('detail', [PostController::class, 'detail']);
    Route::post('create', [PostController::class, 'create']);
    Route::post('update', [PostController::class, 'update']);
    Route::get('delete', [PostController::class, 'delete']);
});
