<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Response\MyResponse;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Str;

class PostController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['view', 'detail']]);
    }

    public function view(Request $request)
    {
    }

    public function detail(Request $request)
    {
    }

    public function create(Request $request)
    {
        if (auth()->user()->can('create post')) {
            if ($file = $request->file('thumbnail')) {
                $title = $request->input('title');
                $content = $request->input('content');
                $slug = Str::slug($title);

                $fileName = Carbon::now()->timestamp . '_' . $slug . '.' . $file->extension();
                $destinationPath = 'uploads/posts/';
                $file->move($destinationPath, $fileName);

                $post = new Post();
                $post->title = $title;
                $post->content = $content;
                $post->slug = $slug;
                $post->thumbnail = $destinationPath . $fileName;
                $post->created_by = auth()->user()->id;
                $post->updated_by = auth()->user()->id;

                $post->save();

                return (new MyResponse())->Response(200, 'Thêm mới bài viết thành công', $post, null);
            } else {
                return (new MyResponse)->Response(
                    Response::HTTP_FORBIDDEN,
                    'File không tồn tại',
                    null,
                    null
                );
            }
        } else {
            return (new MyResponse)->Response(
                Response::HTTP_FORBIDDEN,
                'User không có quyền tạo mới "Bài viết"',
                null,
                null
            );
        }
    }

    public function update(Request $request)
    {
    }

    public function delete(Request $request)
    {
    }
}
