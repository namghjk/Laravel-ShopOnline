<?php

namespace App\Http\Controllers;

use App\Helpers\Pagination;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['view']]);
    }

    public function view(Request $request)
    {
        // Lấy danh sách sản phẩm có phân trang (truyền page, pageSize)
        return (new Pagination())->Pagination('products', 'id', 'desc', $request);
    }
}
